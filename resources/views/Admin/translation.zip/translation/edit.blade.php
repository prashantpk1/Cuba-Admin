<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="commonModal">{{ translate('Edit Translation') }}</h4>
        <button class="btn-close py-0" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <form class="row g-3 needs-validation" novalidate="" action="{{ route('admin.translations.update', encryptString($data->id)) }}"
            method="POST">
            @csrf
            @method('PUT')
            <div class="col-md-12">
                <label class="form-label" for="name">{{ translate('Key') }}: {{ $data->lang_value }}</label>
            </div>
            <div class="col-md-12">
                <label class="form-label" for="en_value">{{ translate('En') }}</label>
                <textarea name="en_value" id="en_value" cols="4" rows="4" class="form-control">{{ $data->lang_value }}</textarea>
            </div>
            <div class="col-md-12">
                <label class="form-label" for="name">{{ translate('Ar') }}</label>
                <textarea name="ar_value" id="ar_value" cols="4" rows="4" class="form-control">{{ (!empty($traslate_lang)) ? $traslate_lang->lang_value : "" }}</textarea>
            </div>
            <div class="col-md-12">
                <button class="btn btn-primary" type="submit">{{ translate('Submit') }}</button>
            </div>
        </form>
    </div>
</div>
