@extends('admin.layouts.app')
@section('title-tag')
<title>{{ translate('Translation List') }}</title>
@endsection
@section('page-title')
    @include('admin.layouts.common.page-title', [
        'parentPageTitle' => translate('Dashboard'),
        'pageTitle' => translate('Translation List'),
    ])
@endsection
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="list-product-header">
                            <div>
                                @can('translation-create')
                                    <a class="btn btn-primary" data-url="{{ route('admin.translations.create') }}" data-size="m"
                                    href="#" data-ajax-model="true"><i class="fa fa-plus"></i>{{ translate('Add Translation') }}</a>
                                @endcan
                            </div>
                        </div>
                        <div class="list-product table-responsive">
                            <table class="table" id="translation-data-table">
                                <thead>
                                    <tr>
                                        <th> <span class="f-light f-w-600">{{ translate('Sr No') }}</span></th>
                                        <th> <span class="f-light f-w-600">{{ translate('Key') }}</span></th>
                                        <th> <span class="f-light f-w-600">{{ translate('Ar Translation') }}</span></th>
                                        <th> <span class="f-light f-w-600">{{ translate('Action') }}</span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer-script')
    <script type="text/javascript">
        $(document).ready(function() {
            var table = $('#translation-data-table').DataTable({
                processing: true,
                serverSide: true,
                language: {
                    processing: '<span class="text-primary spinner-border"></span>'
                },
                order: [],
                ajax: "{{ route('admin.translations.index') }}",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false,
                    },
                    {
                        data: 'key',
                        name: 'key'
                    },
                    {
                        data: 'trans_ar',
                        name: 'trans_ar'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
            BASSEQA.table = table;
        });
    </script>
@endsection
